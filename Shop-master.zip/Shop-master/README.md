# Shop
Shop Laptop, Phone, Watch, PC, Tablet ASP.NET MVC5 - Đồ án chuyên ngành CNTT Hutech
# Công nghệ sử dụng
Bootstrap/Jquery
ASP.NETMVC5/EF6/SQLServer
# Ảnh sản phẩm
![image](https://user-images.githubusercontent.com/66912536/225206994-d9290521-da00-4321-bc62-cb21b8e51d19.png)
# Database
![image](https://user-images.githubusercontent.com/66912536/225207217-1016fc60-99e6-4250-90af-a297fb956d02.png)
# Hỗ trợ thành toán Online
![image](https://user-images.githubusercontent.com/66912536/225207332-81173613-9784-4595-82dd-bfdbbd4b7f31.png)
![image](https://user-images.githubusercontent.com/66912536/225207382-b014e8fd-4a73-40c2-9b3d-3e595f654b53.png)
![image](https://user-images.githubusercontent.com/66912536/225207424-dc47b06b-5c51-44ad-b659-9096b2f5b335.png)
