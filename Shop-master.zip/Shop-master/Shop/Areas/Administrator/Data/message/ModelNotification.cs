﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Shop.Areas.Administrator.Data.message
{
    public class ModelNotification
    {
        public String mgs { get; set; }
        public String mgs_type { get; set; }
    }
}