export const DOUTUBE_API_HOST = "https://api.doutu.be/api/";
