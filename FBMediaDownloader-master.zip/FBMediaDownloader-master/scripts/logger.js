export const log = (...params) => {
  console.log(...params);
};
