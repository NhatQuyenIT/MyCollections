Tất cả LINKS hình ảnh/video bạn tải sẽ được lưu tại đây
