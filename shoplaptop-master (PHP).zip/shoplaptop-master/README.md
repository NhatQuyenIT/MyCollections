<h1>Website mua bán Laptop</h1>
Website được xây dựng với các chức năng cơ bản của một trang web thương mại điện tử<br>
Mục tiêu: cung cấp giao diện người dùng trực quan, dễ sử dụng cho cả phía người dùng và admin<br><br>
<b>Trang chủ</b><br>
<img src="https://user-images.githubusercontent.com/66792742/87221306-3f6ef080-c395-11ea-9429-6160da39bca5.png"><br>
<b>Chi tiết sản phẩm</b><br>
<img src="https://user-images.githubusercontent.com/66792742/87895063-aca61400-ca6e-11ea-9acf-291483df8d3e.png"><br>
<b>Giỏ hàng</b><br>
<img src="https://user-images.githubusercontent.com/66792742/87371777-3a39bd80-c5b0-11ea-9291-11d8045caff6.png"><br>
<b>Dashboard Admin</b><br>
<img src="https://user-images.githubusercontent.com/66792742/87222063-df7b4880-c39a-11ea-86b3-3fe91bf17402.png">


