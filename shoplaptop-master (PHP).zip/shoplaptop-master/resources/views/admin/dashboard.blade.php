 @extends('admin_layout')     {{-- ke thua lai cua trang admin_layout --}}  {{-- ket noi vs adminlayout --}}
 @section('admin_content')		{{-- noi nao nhan trang nay thi goi ra --}}
 <h3><font color="white">Chào mừng bạn đến với trang quản lý MY-COMPUTER</font></h3>
 @endsection
