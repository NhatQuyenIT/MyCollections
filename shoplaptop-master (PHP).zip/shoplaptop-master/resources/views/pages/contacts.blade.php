@extends('layout_contact')
@section('content')


<div class="features_items" style="text-align: center; font-size: 18px;"><!--features_items-->

</div><!--features_items-->

@endsection
