export class Card{
    maMH:number = 0;
    ten = '';
    donGia = 0;
    hinhanh = '';
    moTa = '';
    Quantity:any =0;
}