export class Data {
    id!: number;
    name!: string;
   giaban!: number;
}