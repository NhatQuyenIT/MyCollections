export class Product{
    maMH:number = 0;
    ten = '';
    soLuong:number = 0;
    donGia = 0;
    hinhanh = '';
    moTa = '';

}