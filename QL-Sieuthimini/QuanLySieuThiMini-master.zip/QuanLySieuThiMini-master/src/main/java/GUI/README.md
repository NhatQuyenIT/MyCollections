# Folder này sẽ chứa các thư mục liên quan đến giao diện
Các giao diện chính sẽ được sử dụng:

<img src = "../../../../git_img/chucnang/Slide1.PNG">
