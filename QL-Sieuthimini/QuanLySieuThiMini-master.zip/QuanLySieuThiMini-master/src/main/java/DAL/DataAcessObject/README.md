# Folder này sẽ chứa các thư mục liên quan đến truy cập dữ liệu từ database
Các hoạt động thêm xóa sửa (CRUD) sẽ được định nghĩa và implement ở đây