# Folder này sẽ chứa các thư mục liên quan đến kết nối database
Các hoạt động sử dụng username, password, url để kết nối database bằng JDBC sẽ được thực hiện ở đây
Phải try catch các lỗi và xuất ra theo lỗi tự định nghĩa