# Folder này sẽ chứa các thư mục liên quan chức năng, xử lý hành động, xuất ra GUI
Các hành động chính bao gồm:
- Thanh toán:
    + Tìm kiếm voucher tốt nhất nếu khách hàng được lưu trong database:
        -> tính tổng giảm giá sản phẩm và voucher
    + Tổng tiền
    + Thanh toán 
    + Lưu danh sách chi tiết hóa đơn
    + Lưu hóa đơn
- Kiểm tra:
    + Kiểm tra số lượng sản phẩm trước khi đưa vào hóa đơn
    + Kiểm tra mã khách hàng
    + Kiểm tra mã voucher
    