# Folder này sẽ chứa các thư mục liên quan chức năng, xử lý hành động, xuất ra GUI
Các hành động chính bao gồm:
- Thanh toán
- Nhập mã khuyến mãi
- Xuất hóa đơn
- Nhập xuất file excel
- Thống kê doanh thu
- Tìm kiếm, thêm xóa sửa đối tượng