# Folder này sẽ chứa các thư mục liên quan đến chứa dữ liệu database
Khi thực hiện thao tác thêm xóa sửa, cần có 1 thành phân trung gian để giao tiếp giữa database và java object
Các dữ liệu lấy được từ database sẽ dùng hàm khởi tạo của các class này để tạo object. Từ objet đó, ta có thể thay đổi và chuyển ngược lại thành database