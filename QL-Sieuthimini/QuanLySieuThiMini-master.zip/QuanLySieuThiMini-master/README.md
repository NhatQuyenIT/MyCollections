# QuanLySieuThiMini
Đồ án quản lý siêu thị mini Java SGU

Các bước để code chung:
1. Fork dự án trên github riêng
2. Thực hiện clone dự án trên github riêng về máy
3. Sau khi thực hiện một số thay đổi thì các file thay đổi (git add .) và (git commit -m "Message gi do") để đặt tên cho thay đổi
4. Thực hiện lệnh git push origin master để đẩy lên github riêng (nếu yêu cầu đăng nhập thì đăng nhập bth)
5. Tạo pull request gửi đến project chính https://github.com/huykhaduy/QuanLySieuThiMini (nếu xảy ra xung đột, tìm các chỗ xung đột sửa)
6. Chờ xác nhận  

Nếu có xảy ra lỗi liên hệ <a href="https://www.facebook.com/huykhaduy">Facebook</a>
