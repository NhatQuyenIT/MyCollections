# Khởi tạo database cho đồ án (XAMPP)
- Sử dụng cơ sở dữ liệu MYSQL hoặc MariaDB
- Run code ở file db.sql

Hình ảnh database:
<img src ="../git_img/database/SieuThiMiniDatabase.png">
