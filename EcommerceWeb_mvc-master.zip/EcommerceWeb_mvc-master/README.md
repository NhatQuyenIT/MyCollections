# EcommerceWeb_mvc

Website bán đồ điện tử: điện thoại, laptop, phụ kiện,...

### Các bước cài đặt và chạy project:

#### B1: clone về máy = lệnh "git clone https://github.com/LaurelWreath1804/EcommerceWeb_mvc.git"

#### B2: copy project vừa clone vào trong folder "htdocs" của xampp ( tải và cài đặt xampp từ trước)

#### B3: Bật xampp, start apache và mySQL

#### B4: trong phpAdmin: tạo cơ sở dữ liệu tên "website_mvc" và chạy file sql để tạo database

#### B5: mở project lên, vào link "localhost/ecommerceweb_mvc" , để vào trang admin vào link "localhost/ecommerceweb_mvc/admin"

### Có thể mở trang web như 1 khách hàng bằng cách truy cập vào "https://ecommercewebmvc.000webhostapp.com/"

### Có thể mở trang web như 1 admin bằng cách truy cập vào "https://ecommercewebmvc.000webhostapp.com/admin"

![image](https://user-images.githubusercontent.com/93032912/179794495-23aa184b-c2e5-42dd-b93e-3fce56d6fa77.png)

![image](https://user-images.githubusercontent.com/93032912/179794816-18554bc4-3c6c-42ae-8256-7b9a371d960d.png)
