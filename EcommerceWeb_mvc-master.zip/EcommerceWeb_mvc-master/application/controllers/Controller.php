<?php

interface Controller {
    //Show view 
    function render();
}